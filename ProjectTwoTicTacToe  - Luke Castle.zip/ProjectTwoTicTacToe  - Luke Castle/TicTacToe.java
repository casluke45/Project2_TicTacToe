import java.util.*;

public class TicTacToe{
	Random rnd = new Random();
	static Scanner sc = new Scanner(System.in);

	static boolean again = true;
	static int turns = 0;


	public static void main(String[] args){
		// --------------- Introduction to the game -----------------------
		System.out.println(Rules());
		System.out.println("Please enter the first player's name: ");
		String name1 = sc.nextLine();
		System.out.println("Please enter the second player's name: ");
		String name2 = sc.nextLine();

		Player player1 = new Player(name1);
		Player player2 = new Player(name2);
		// ----------------------------------------------------------------


		while (again){                                  // Uses 2 seperate while loops 
			ArrayList<Integer> arrli = createList();    // The first loop contains varriables that will need to be recreated each time the players play again
			Board board = new Board();                  // The second loop contains all the meat and mechanics of the game that is repeated each turn.
			Boolean isValidInput;
			whoGoesFirst(board, player1, player2);
			while (board.getPlayer1Win() == false && board.getPlayer2Win() == false && turns < 9){
				int input = 0;
				isValidInput = false;
				if (board.getPlayerTurn() > 0){
					System.out.println(player1.getName() + "'s turn!");
				}
				else{
					System.out.println(player2.getName() + "'s turn!");
				}
				System.out.println(board +"\n Please choose the number on the board you would like to occupy: ");

				// --- Input Validation ----------------------------------------------------------------------------
				while (!isValidInput){
					try{
						input = sc.nextInt();
						if (arrli.get(input -1) != 0){
							arrli.set(input - 1, 0);
							isValidInput = true;
							break;
						}
						else{
							throw new Exception();
						}	
					}
					catch (InputMismatchException e){
						System.out.println("Invalid input, please enter an int from 1-9: " + sc.nextLine());
					}
					catch (IndexOutOfBoundsException i){
						System.out.println("Invalid input, your int must be from 1-9: ");
					}
					catch (Exception n){
						System.out.println("That space is already occupied: ");
					}
				}
				// -------------------------------------------------------------------------------------------------

				board.update(input);
				board.checkWinState();
				board.nextPlayer();
				turns ++;
			}
			if (board.getPlayer1Win() == true){
				player1.playerWin();
				player2.playerLoss();
				System.out.println(board + "\n" + player1.getName() + " wins!");
			}
			else if (board.getPlayer2Win() == true){
				player1.playerLoss();
				player2.playerWin();
				System.out.println(board + "\n" + player2.getName() + " wins!");
			}
			else if (turns == 9 && board.getPlayer1Win() == false && board.getPlayer2Win() == false){
				player1.playerTie();
				player2.playerTie();
				System.out.println(board + "\n" + "It's a tie!");
			}

			again = Again(board);
		}
		System.out.println(player1);
		System.out.println(player2);
	}

	public static String Rules(){
		String result = "---------------------RULES----------------------------------------------------\n" + 
		                "|    Each player takes turns placing their marker (Either an X or an O)      |\n" + 
		                "|    and the first player to match 3 of their own markers in a row,          |\n" + 
		                "|    whether it be horrizontal, vertical, or diagonal, wins the game.        |\n" +
		                "|                                                                            |\n" + 
		                "|    You will play in a 3x3 grid where each space is numbered 1-9. When      |\n" + 
		                "|    pompted, please select the number of the space you would like to        |\n" + 
		                "|    occupy. That space will then show up as your marker and be unavailable  |\n" +
		                "|    for the other player to occupy.                                         |\n" +
		                "|                                                                            |\n" +
		                "|    It's also possible for the game to end in a tie. This happens when the  |\n" +
		                "|    board is fully occupied but there are no markers lying 3 in a row.      |\n" +
		                "|                                                                            |\n" +
		                "|    You may play however many games you desire and the player with the most |\n" + 
		                "|    wins when you decide to end will be the ultimate winner.                |\n" +
		                "|                                                                            |\n" + 
		                "|    You will start by determining who is 'X' and who is 'O'                 |\n" +
		                "------------------------------------------------------------------------------";
		return result;
	}

	public static boolean Again(Board board){
		Boolean loop = true;
		System.out.println("Would you like to play again? (y or n)");

		while (loop){
			String choice = sc.nextLine();
			if (choice.equals("y")){
				turns = 0;
				board.setPlayer1Win(false);
				board.setPlayer2Win(false);
				return true;
			}
			else if (choice.equals("n")){
				break;
			}
			System.out.println("Invalid input, please enter y or n");
		}
		return false;
	}

	public static void whoGoesFirst(Board board, Player player1, Player player2){
		Random rnd = new Random();
                                                                                       // Determains randomly which player goes first between the two.
		int guess = rnd.nextInt(2);                                                    // Function is called every new game they play

		while(guess == 1){
			if (board.getPlayerTurn() == 1){
				System.out.println(player1.getName() + " will go first!");
				break;
			}									//Player1 goes first
			if (board.getPlayerTurn() == -1){
				board.nextPlayer();
			}
		}

		while(guess == 0){
			if (board.getPlayerTurn() == 1){
				board.nextPlayer();
			}									//Player2 goes first
			if (board.getPlayerTurn() == -1){
				System.out.println(player2.getName() + " will go first!");
				break;
			}
		}

	}

	public static ArrayList<Integer> createList(){
		ArrayList<Integer> arli = new ArrayList<Integer>(9);
		for (int i = 1; i < 10; i++){
			arli.add(i);                                           // creates the arraylist used to tell if a space has been occupied or not.
		}
		return arli;
	}

}