import java.util.*;

public class Player{

//---------- Player specific varriables---------
	private String name;
	private int wins, losses, ties;
	private int myNum = 0;
//----------------------------------------------

//-------- Constructor -------------------------
	public Player(String nm){
		name = nm.toUpperCase();
		wins = 0;
		losses = 0;
		ties = 0;
	}
//----------------------------------------------

	public void playerWin(){
		this.wins ++;
	}
	public void playerLoss(){
		this.losses ++;
	}
	public void playerTie(){
		this.ties ++;
	}






//--------- Getters/Setters ----------------------
	public String getName(){
		return name;
	}

	public void setName(String nm){
		nm.toUpperCase();

		while (name.equals(nm) == false){
		this.name = nm;
		}
	}

	public int getTies(){
		return ties;
	}

	public int getWins(){
		return wins;
	}

	public int getLosses(){
		return losses;
	}

	public void resetTies(){
		this.ties = 0;
	}

	public void resetWins(){
		this.wins = 0;
	}

	public void resetLosses(){
		this.losses = 0;
	}
//------------------------------------------------

	public String toString(){
		return name + " has " + wins + " wins, " + losses + " losses, and " + ties + " ties.";
	}
}