import java.util.*;

public class Board{
	//                             
	private int[][] boardState = {{0, 0, 0},             
	                              {0, 0, 0},				
	                              {0, 0, 0}};              

	private String[][] boardMap = new String[3][3];    //      {{1, 2, 3},
	                                                  // 		{4, 5, 6},
	                              				     //         {7, 8, 9}}                         

	private String currentBoard;
	private int playerTurn = 1;
	private Boolean player1Win = false;
	private Boolean player2Win = false;

// ------ Constructor ----------------------------------------------------------------------------------------
	public Board(){
		int b = 1;
		for (int i = 0; i < 3; i++){
			for (int j = 0; j < 3; j++){
				boardMap[i][j] = Integer.toString(b);    // Fills the array boardMap with the numbers 1-9 so it looks like the array above ^
				b++;
			}
			
		}

		currentBoard = 
					   "  -------------\n" +
					   "  |  "+boardMap[0][0]+"  "+boardMap[0][1]+"  "+boardMap[0][2]+"  |\n" + 
					   "  |  "+boardMap[1][0]+"  "+boardMap[1][1]+"  "+boardMap[1][2]+"  |\n" +   // Current board will be whats used to show to the player
					   "  |  "+boardMap[2][0]+"  "+boardMap[2][1]+"  "+boardMap[2][2]+"  |\n" + 
					   "  -------------";


	}
// ----------------------------------------------------------------------------------------------------------

	public void update(int input){
		String in = Integer.toString(input);
		for (int i = 0; i < 3; i++){                                      //  the update function takes the input of which space the player wants to occupy
			for (int j = 0; j < 3; j++){                                  //  and makes sure the space is available to be taken. It then checks which 
				if (boardState[i][j] == 0 && boardMap[i][j].equals(in)){  //  player made the choice and fills in the space they see with either their X
					if (playerTurn > 0){                                  //  or O. The function updates both what the users see (boardMap & currentBoard)
						boardMap[i][j] = "O";                             //  and updates what the game keeps track of to tell if a player has won (boardState).
						boardState[i][j] = 1;                             //
					}                                                     //
					else if (playerTurn < 0){                             //  It then updates the currentBoard String to accurately display the newly occupied 
						boardMap[i][j] = "X";                             //  spaces.
						boardState[i][j] = 2;                             //
					}
				}
			}
		}
		currentBoard = 
					   "  -------------\n" +
					   "  |  "+boardMap[0][0]+"  "+boardMap[0][1]+"  "+boardMap[0][2]+"  |\n" + 
					   "  |  "+boardMap[1][0]+"  "+boardMap[1][1]+"  "+boardMap[1][2]+"  |\n" + 
					   "  |  "+boardMap[2][0]+"  "+boardMap[2][1]+"  "+boardMap[2][2]+"  |\n" + 
					   "  -------------";
	}

	public void checkWinState(){
		for (int i = 1; i < 3; i++){
			if (boardState[0][0] == i && boardState[0][1] == i && boardState[0][2] == i ||
				boardState[1][0] == i && boardState[1][1] == i && boardState[1][2] == i ||     //Horrizontal Wins
				boardState[2][0] == i && boardState[2][1] == i && boardState[2][2] == i){
				if (i == 1){
					player1Win = true;
				}
				else{
					player2Win = true;
				}
			}
			else if (boardState[0][0] == i && boardState[1][0] == i && boardState[2][0] == i ||
				     boardState[0][1] == i && boardState[1][1] == i && boardState[2][1] == i ||    //Vertical Wins
				     boardState[0][2] == i && boardState[1][2] == i && boardState[2][2] == i){
				if (i == 1){
					player1Win = true;
				}
				else{
					player2Win = true;
				}
			}
			else if (boardState[0][0] == i && boardState[1][1] == i && boardState[2][2] == i ||  //Diagonal Wins
				     boardState[2][0] == i && boardState[1][1] == i && boardState[0][2] == i){
				if (i == 1){
					player1Win = true;
				}
				else{
					player2Win = true;
				}
			}
		}
	}

	public void nextPlayer(){
		playerTurn *= -1;
	}

//----------- Getters/Setter ------------------------------

public Boolean getPlayer1Win(){
	return player1Win;
}
public Boolean getPlayer2Win(){
	return player2Win;
}
/*public void setPlayer1Win(Boolean p){
	player1Win = p;
}
public void setPlayer2Win(Boolean p){
	player2Win = p;
}*/
public int getPlayerTurn(){
	return playerTurn;
}

//---------------------------------------------------------

	public String toString(){
		return currentBoard;
	}
}